# Библиотеки

import os
import pyttsx3

# Функции, импортированные из библиотек

from time import sleep
from datetime import datetime

# Инициализация библиотек

voice_engine = pyttsx3.init()
voice_engine.setProperty("rate", 230)

## Переменные, списки и т.д.

# Список тестов
tests = ['test1', 'test2', 'test3', 'test4', 'test5', 'test6', 'test7', 'test8', 'test9', 'test10', 'test11', 'test12', 'test13']

# Теория
theory = {
    "Present Simple": {
        "Утверждение": "I / We / You / They + V\nShe / He / It + V + s (es)\nПример: I go to work every day.",
        "Отрицание": "I / We / You / They + do not (don’t) + V\nShe / He / It + does not (doesn’t) + V\nПример: I don’t go to school every day.",
        "Вопрос": "Do + I / we / you / they + V ?\nDoes + she / he / it + V ?\nПример: Do you like pizza?",
        "Глагол to be": "am (для I), is (для she / he / it), are (для we / you / they)\nПример: I am ready."
    },
    "Present Continuous": {
        "Утверждение": "I am + V-ing\nHe/She/It is + V-ing\nWe/You/They are + V-ing\nПример: I am singing.",
        "Отрицание": "I am not + V-ing\nHe/She/It is not + V-ing\nWe/You/They are not + V-ing\nПример: I am not singing.",
        "Вопрос": "Am I + V-ing?\nIs He/She/It + V-ing?\nAre We/You/They + V-ing?\nПример: Am I singing?"
    },
    "Past Simple": {
        "Утверждение": "Местоимение + глагол-ed\nПример: He looked at me once.",
        "Отрицание": "Подлежащее + did not + инфинитив\nПример: Tom did not eat porridge.",
        "Вопрос": "Did + подлежащее + инфинитив?\nПример: Did Tom eat porridge?"
    },
    "Future Simple": {
        "Утверждение": "I / She / He / It / We / You / They + will + V\nПример: I will read a book.",
        "Отрицание": "I / She / He / It / We / You / They + will not (won’t) + V\nПример: I will not take your bag.",
        "Вопрос": "Will + подлежащее + V?\nПример: Will Tom eat porridge?"
    },
    "Сравнительная степень прилагательных": {
        "Односложные прилагательные": "Суффикс -(e)r: cold — colder\nПример: big — bigger.",
        "Двусложные прилагательные": "Прилагательные на -y меняются на -i: busy — busier\nПример: clever — cleverer.",
        "Многосложные прилагательные": "Слово 'more' перед прилагательным: interesting — more interesting.",
        "Исключения": "good — better, bad — worse, far — farther/further."
    }
}

# Переменная для функции просмотра и удаления файлов

results_folder = "results"

# Переменная для отключения функции озвучки

is_voiceover = False
is_asking = True
### Функции программы

## Основное

# Обработка результатов
def p_processing(p, n, t): #p - баллы, n - число заданий, t - номер теста
    if not os.path.exists(results_folder):
        os.makedirs(results_folder)
    quotient_value = p / n
    percentage_value = quotient_value * 100
    display(f'Ваш балл: {p} ({round(percentage_value)}%)')
    sleep(1)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"test{t}_result_{timestamp}.txt"
    filepath = os.path.join(results_folder, filename)

    with open(filepath, "w") as result_file:
        result_file.write(f"Результаты теста {t}\n")
        result_file.write(f"Правильные ответы: {p} из {n}\n")
        result_file.write(f"Успешность: {round(percentage_value)}%\n")

    display(f"Результат сохранен в файл {filename}")
    delete = input("Хотите удалить файл результата? (y/n): ")
    if delete.lower() == 'y':
        delete_file(filename)

# Удаление файлов
def delete_file(filepath):
    if os.path.exists(filepath):
        os.remove(filepath)
        print(f"Файл {filepath} успешно удален.")
    else:
        display("Файл не найден.")

# Открытие файлов с результатами
def show_file_content():
    result_files = list_result_files()
    if not result_files:
        return
    display("\nВведите имя файла, который хотите открыть: ")
    file_name = input()
    results_folder = "results"
    file_path = os.path.join(results_folder, file_name)

    if os.path.isfile(file_path):
        try:
            # Пытаемся прочитать файл с UTF-8
            with open(file_path, "r", encoding="utf-8") as file:
                content = file.read()
        except UnicodeDecodeError:
            # Если ошибка кодировки, читаем с cp1251
            with open(file_path, "r", encoding="cp1251") as file:
                content = file.read()

        print(f"\nСодержимое файла {file_name}:\n")
        print(content)
    else:
        print("Файл не найден.")

# Функция по выводу теории
def display_theory():
    display("\n\nВыберите раздел теории:")
    for i, section in enumerate(theory, 1):
        print(f"{i}. {section}")
    sleep(0.5)
    section_choice = input("Введите номер раздела: ")
    sleep(0.5)

    try:
        section_choice = int(section_choice) - 1
        selected_section = list(theory.keys())[section_choice]
        display(f"\nРаздел: {selected_section}")

        rules = theory[selected_section]
        for j, rule in enumerate(rules, 1):
            display(f"{j}. {rule}")
        rule_choice = input("Введите номер правила: ")

        try:
            rule_choice = int(rule_choice) - 1
            selected_rule = list(rules.keys())[rule_choice]
            display(f"\nПравило: {selected_rule}\n{rules[selected_rule]}")
        except (ValueError, IndexError):
            display("Неверный выбор правила.")
    except (ValueError, IndexError):
        display("Неверный выбор раздела.")

# Озвучивание текста

def display(text):
    print(text)
    if is_voiceover:
        voice_engine.say(text)
        voice_engine.runAndWait()
        
# Отключение/включение озвучки

def voiceover():
    global is_voiceover, is_asking
    if is_asking:
        start = input(
            'Отключить/включить озвучку? (nmore - больше не спрашивать; сохранится предыдущее значение (по умолчанию - выкл) [on/off/nmore]: ')

        if start == 'on':
            is_voiceover = True
        elif start == 'off':
            is_voiceover = False
        elif start == 'nmore':
            is_asking = False
        else:
            print('Неверные данные ввода. Старт без озвучки.')
            is_voiceover = False

    return is_voiceover, is_asking

## Тесты

def test1():
    s1 = 0

    display('I … in a bank. (work)')
    answer = str.lower(input())
    if answer == "work":
        display("cool")
        s1 += 1
    else:
        display("loser")

    display("Harry … in London. (live)")
    answer = str.lower(input())
    if answer == "lives":
        display("cool")
        s1 += 1
    else:
        display("loser")

    display("My cat … fish every day. (eat)")
    answer = str.lower(input())
    if answer == "eats":
        display("cool")
        s1 += 1
    else:
        display("loser")
    p_processing(s1,3, 1)



def test2():
    s1 = 0
    display("I… to school now. (go)")
    answer = str.lower(input())
    if answer == "am going":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("He … in the park. (walk)")
    answer = str.lower(input())
    if answer == "is walking":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("They … the walls. (paint)")
    answer = str.lower(input())
    if answer == "are painting":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    p_processing(s1,3, 2)


# ----------------------------------------

##паст симпл
# ----------------------------------------
def test3():
    s1 = 0
    display("James … born on july 2, 1999. (be)")
    answer = str.lower(input())
    if answer == "was":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("I… my best friend at University 5 years ago. (meet)")
    answer = str.lower(input())
    if answer == "met":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("Lina and I … to the cinema last week. (go)")
    answer = str.lower(input())
    if answer == "went":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    p_processing(s1,3, 3)

# ----------------------------------------


# фьюче симпл
# ----------------------------------------
def test4():
    s1 = 0
    display("Sue … a shower in the evening. (take)")
    answer = str.lower(input())
    if answer == "will take":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("We … for a walk after lunch. (go)")
    answer = str.lower(input())
    if answer == "will go":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("They… on time for the class. (be)")
    answer = str.lower(input())
    if answer == "will be":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    p_processing(s1,3, 4)


# презент симпл ор континиус
# ----------------------------------------
def test5():  # num - кол-во заданий
    s1 = 0
    display("He … for a big insurance company.(works)")
    answer = str.lower(input())
    if answer == "works":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("Water always … at 100 degrees.(boils)")
    answer = str.lower(input())
    if answer == "boils":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("I …  for my doctor at the moment.(am waiting)")
    answer = str.lower(input())
    if answer == "am waiting":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("Bob, stop! You …  too fast. (eat)")
    answer = str.lower(input())
    if answer == "are eating":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("She… four brothers. (have)")
    answer = str.lower(input())
    if answer == "has":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    p_processing(s1,5,5)


# все симплы
# ----------------------------------------
def test6():
    s1 = 0
    display("walk / every morning / I / my dog")
    answer = str.lower(input())
    if answer == "I walk with my dog every day":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("by taxi / She / goes / usually / to work")
    answer = str.lower(input())
    if answer == "She usually goes to work by taxi":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("sometimes / to the cinema / go / we")
    answer = str.lower(input())
    if answer == "We sometimes go to the cinema":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("you / He / tomorrow morning / will / call")
    answer = str.lower(input())
    if answer == "He will call you tomorrow morning":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("at 11 am / they / arrive / tomorrow / will")
    answer = str.lower(input())
    if answer == "They will arrive at 11 am tomorrow":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    p_processing(s1,5,6)


# ----------------------------------------


# ----------------------------------------
def test7():
    s1 = 0
    display("yesterday / you / did / to work / go ?")
    answer = str.lower(input())
    if answer == "Did you go to work yesterday?":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("Do / study / at college / you / economics ?")
    answer = str.lower(input())
    if answer == "Do you study economics at college?":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("the book / tomorrow / you / give me / Will?")
    answer = str.lower(input())
    if answer == "Will you give me the book tomorrow?":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("he / does / What music / like?")
    answer = str.lower(input())
    if answer == "What music does he like?":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("go to bed / Sarah / Why / late / did?")
    answer = str.lower(input())
    if answer == "Why did Sarah go to bed late?":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    p_processing(s1,5,7)


# ----------------------------------------

# ----------------------------------------
def test8():
    s1 = 0
    display("Твоя девушка итальянка?")
    answer = str.lower(input())
    if answer == "Are your girlfriend Italian?":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("Я боюсь пауков")
    answer = str.lower(input())
    if answer == "I am afraid of spiders":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("Вчера в нашем кафе было много туристов")
    answer = str.lower(input())
    if answer == "There were a lot of tourists in our café yesterday":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("Питер будет следующей зимой в Африке")
    answer = str.lower(input())
    if answer == "Peter will be in Africa next winter":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("Мы никогда не опаздываем на наши уроки рисования")
    answer = str.lower(input())
    if answer == "We are never late for our Drawing classes":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    p_processing(s1,5,8)


# ----------------------------------------


# ----------------------------------------
def test9():
    s1 = 0
    display("The 1 st of September isn't the… day. (long)")
    answer = str.lower(input())
    if answer == "longest":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("The mouse is … than the cat. (small)")
    answer = str.lower(input())
    if answer == "smaller":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display(" It is a very … English book. (funny)")
    answer = str.lower(input())
    if answer == "funniest":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("He is a … boy. (nice)")
    answer = str.lower(input())
    if answer == "nice":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("My hands are… than your hands. (clean)")
    answer = str.lower(input())
    if answer == "cleaner":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    p_processing(s1,5,9)


# ----------------------------------------

# ----------------------------------------
def test10():
    s1 = 0
    display("Parrots are… than hens.(small)")
    answer = str.lower(input())
    if answer == "smaller":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("Monkey's tail is … than pig's tail. (long)")
    answer = str.lower(input())
    if answer == "longer":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display(" Cows are … than horses. (fat)")
    answer = str.lower(input())
    if answer == "fatter":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("Granny is … than Grandpa. (short)")
    answer = str.lower(input())
    if answer == "shorter":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("Apples are…  than carrots. (tasty)")
    answer = str.lower(input())
    if answer == "tastier":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    p_processing(s1,5,10)


# ----------------------------------------


# ----------------------------------------
def test11():
    s1 = 0
    display("Ann is… than Kate. (beautiful)")
    answer = str.lower(input())
    if answer == "more beautiful":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("Russia is… country. (large)")
    answer = str.lower(input())
    if answer == "larger ":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("This man is … than that one. (tall)")
    answer = str.lower(input())
    if answer == "taller":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("He is … than I. (happy)")
    answer = str.lower(input())
    if answer == "happier":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display(" Today is … than it was yesterday. (cold)")
    answer = str.lower(input())
    if answer == "colder":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    p_processing(s1,5,11)


# ----------------------------------------


# ----------------------------------------
def test12():
    s1 = 0
    display("New York is … than Washington. (big)")
    answer = str.lower(input())
    if answer == "bigger":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("Princess Fiona is … than Shrek. (beautiful)")
    answer = str.lower(input())
    if answer == "more beautiful":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("A cat is smaller than a tiger. (small)")
    answer = str.lower(input())
    if answer == "smaller":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("Winnie-the-Pooh is … than Rabbit. (fat)")
    answer = str.lower(input())
    if answer == "fatter":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display(" Tyumen is … than Moscow. (less)")
    answer = str.lower(input())
    if answer == "lesser":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    p_processing(s1,5,12)

# ----------------------------------------

# ----------------------------------------
def test13():
    s1 = 0
    display("This monkey is … than that monkey. (funny)")
    answer = str.lower(input())
    if answer == "funnier":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("This cat is… than that cat. (lazy)")
    answer = str.lower(input())
    if answer == "lazier":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("This woman is … than that woman. (busy)")
    answer = str.lower(input())
    if answer == "busier":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("This book is… than that book. (bad)")
    answer = str.lower(input())
    if answer == "worse":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    display("This pig is … than that pig. (fat)")
    answer = str.lower(input())
    if answer == "fatter":
        display("cool")
        s1 = s1 + 1
    else:
        display("loser")
    p_processing(s1,5,13)


tests_dict = {
    'test1': test1, 'test2': test2, 'test3': test3, 'test4': test4, 'test5': test5,
    'test6': test6, 'test7': test7, 'test8': test8, 'test9': test9, 'test10': test10,
    'test11': test11, 'test12': test12, 'test13': test13
}


def list_result_files():
    results_folder = "results"

    if os.path.exists(results_folder):
        files = os.listdir(results_folder)
        result_files = [f for f in files if os.path.isfile(os.path.join(results_folder, f))]

        if result_files:
            display("Доступные файлы с результатами:\n")
            for file in result_files:
                print(file)
        else:
            display("Нет файлов с результатами.")
            return None
    else:
        display("Папка results не существует.")
        return None

    return result_files




# Объявление завершения загрузки программы (отладка)
print('started')

# Цикл программы
while True:
    voiceover()
    display("Выберите действие:\n1. Пройти тест\n2. Просмотреть теорию\n3. Удалить все результаты тестов\n4. вывести результат теста")
    choice = input("Введите номер действия (1-4): ")
    sleep(0.1)

    if choice == "1":
        display(f"Выберите тест (название теста без кавычек):\n")
        print(tests)
        choose = input()
        test_function = tests_dict.get(choose)
        if test_function:
            test_function()
        else:
            display("Неверный выбор\n")
    elif choice == "2":
        display_theory()
    elif choice == "3":
        confirm = input("Вы уверены? (y/n): ")
        if confirm == "y":

            if os.path.exists(results_folder):
                # Перебор всех файлов в папке
                for filename in os.listdir(results_folder):
                    file_path = os.path.join(results_folder, filename)
                    try:
                        # Удаляем только файлы, игнорируя папки
                        if os.path.isfile(file_path):
                            os.remove(file_path)
                            display(f"Файл {file_path} успешно удалён.")
                    except Exception as e:
                        display(f"Ошибка при удалении файла {file_path}: {e}")
            else:
                display("Папка results не существует.")
        elif confirm == "n":
            display("Действие отменено.")
            sleep(2)
        else:
            display("Неверный выбор, возвращение к главному экрану")
    elif choice == "4":
        show_file_content()
    else:
        display("Неверный выбор\n")